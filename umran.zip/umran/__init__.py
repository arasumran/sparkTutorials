#  Copyright (c) 2023 Wh1isper
#  Licensed under the BSD 3-Clause License

"""Top-level package for umran."""

__author__ = "umran"
__email__ = "@.com"
__version__ = "0.2.2.dev0"

import findspark  # noqa

try:  # noqa
    findspark.init()  # noqa
except Exception:  # noqa
    pass  # noqa
